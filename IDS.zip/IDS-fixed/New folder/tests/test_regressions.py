"""tests/test_regressions.py — Regression tests for bugs found during an audit.

Unlike most other tests in this suite these use *real* Scapy packets and the
*real* wiring from ``main.py`` instead of hand-written mocks, because every one
of these bugs slipped through the mock-based tests.
"""

from __future__ import annotations

import collections
import logging
import queue
import threading
from unittest.mock import MagicMock, patch

import pytest
from scapy.all import ARP, IP, IPv6, TCP, UDP, Ether

from ids.capture import PacketCaptureEngine
from ids.dashboard import create_app
from ids.detection import (
    BruteForceDetector,
    DetectionEngine,
    DoSDetector,
    PortScanDetector,
)
from ids.ip_blocker import IPBlocker
from ids.models import AttackType, Severity


# ---------------------------------------------------------------------------
# Traffic Stats chart
# ---------------------------------------------------------------------------

class TestTrafficStatsWiring:
    def test_create_app_keeps_the_same_empty_deque(self):
        """An EMPTY deque is falsy; ``stats or deque()`` used to replace it."""
        stats = collections.deque(maxlen=60)
        app = create_app(stats_provider=stats)
        assert app.config["STATS_PROVIDER"] is stats

    def test_stats_endpoint_sees_values_appended_after_startup(self):
        """Exactly main.py's wiring: empty deque handed over, filled later."""
        stats = collections.deque(maxlen=60)
        app = create_app(stats_provider=stats, ready=False)
        stats.extend([120, 340, 95])
        data = app.test_client().get("/api/stats").get_json()
        assert data["pps_history"] == [120, 340, 95]
        assert data["pps"] == 95.0

    def test_capture_engine_to_dashboard_end_to_end(self):
        stats = collections.deque(maxlen=60)
        app = create_app(stats_provider=stats)
        engine = PacketCaptureEngine(
            interface="eth0",
            packet_queue=queue.Queue(maxsize=1000),
            bpf_filter=None,
            stop_event=threading.Event(),
            stats_provider=stats,
        )
        app.config["TOTAL_PACKETS_PROVIDER"] = lambda: engine.total_packets

        with patch("ids.capture.time.time") as fake_time:
            engine._current_second = 1000
            fake_time.return_value = 1000.2
            for _ in range(7):
                engine._on_packet(object())
            fake_time.return_value = 1001.1  # next second -> flush the 7
            engine._on_packet(object())

        data = app.test_client().get("/api/stats").get_json()
        assert data["pps_history"] == [7]
        assert data["total_packets"] == 8  # lifetime count, not the window sum

    def test_idle_seconds_are_zero_filled(self):
        stats = collections.deque(maxlen=60)
        engine = PacketCaptureEngine("eth0", queue.Queue(), None, threading.Event(), stats)
        with patch("ids.capture.time.time") as fake_time:
            engine._current_second = 100
            fake_time.return_value = 100.5
            engine._on_packet(object())
            engine._on_packet(object())
            fake_time.return_value = 105.5  # seconds 101-104 saw nothing
            engine._on_packet(object())
        assert list(stats) == [2, 0, 0, 0, 0]

    def test_total_packets_falls_back_to_window_sum(self):
        stats = collections.deque([5, 6, 7], maxlen=60)
        app = create_app(stats_provider=stats)
        assert app.test_client().get("/api/stats").get_json()["total_packets"] == 18


# ---------------------------------------------------------------------------
# Source-IP extraction
# ---------------------------------------------------------------------------

def _engine() -> DetectionEngine:
    cfg = MagicMock()
    cfg.port_scan_threshold = 20
    cfg.port_scan_window_seconds = 10
    cfg.brute_force_threshold = 10
    cfg.brute_force_window_seconds = 10
    cfg.brute_force_ports = [22]
    cfg.dos_threshold_pps = 100
    cfg.dos_window_seconds = 10
    cfg.dos_consecutive_intervals = 3
    return DetectionEngine(MagicMock(), cfg, queue.Queue(), threading.Event())


class TestSourceIpExtraction:
    def test_ipv4(self):
        pkt = Ether() / IP(src="10.0.0.5") / TCP()
        assert _engine()._extract_src_ip(pkt) == "10.0.0.5"

    def test_ipv6_returns_ipv6_address_not_mac(self):
        pkt = Ether(src="5a:f9:60:7e:16:9d") / IPv6(src="fe80::1") / TCP()
        assert _engine()._extract_src_ip(pkt) == "fe80::1"

    def test_arp_is_skipped_instead_of_returning_a_mac(self):
        pkt = Ether(src="02:83:cd:e4:4b:85") / ARP()
        assert _engine()._extract_src_ip(pkt) is None


# ---------------------------------------------------------------------------
# Port scan
# ---------------------------------------------------------------------------

def _feed(detector, packets, src_ip, t0=1000.0, step=0.05):
    alerts = []
    for i, pkt in enumerate(packets):
        a = detector.process(pkt, src_ip, t0 + i * step)
        if a is not None:
            alerts.append(a)
    return alerts


class TestPortScan:
    def test_server_replies_to_many_client_ports_are_not_a_scan(self):
        """A server answering 30 browser connections is not scanning us."""
        replies = [
            Ether() / IP(src="142.250.1.1", dst="10.0.0.5")
            / TCP(sport=443, dport=50000 + i, flags="SA")
            for i in range(30)
        ]
        assert _feed(PortScanDetector(20, 10), replies, "142.250.1.1") == []

    def test_established_traffic_is_not_a_scan(self):
        pkts = [
            Ether() / IP(src="1.1.1.1") / TCP(sport=443, dport=40000 + i, flags="PA")
            for i in range(30)
        ]
        assert _feed(PortScanDetector(20, 10), pkts, "1.1.1.1") == []

    def test_real_syn_scan_still_detected(self):
        probes = [
            Ether() / IP(src="6.6.6.6") / TCP(sport=4444, dport=1000 + i, flags="S")
            for i in range(30)
        ]
        alerts = _feed(PortScanDetector(20, 10), probes, "6.6.6.6")
        assert len(alerts) == 1
        assert alerts[0].attack_type == AttackType.PORT_SCAN

    def test_stealth_fin_scan_still_detected(self):
        probes = [
            Ether() / IP(src="6.6.6.6") / TCP(sport=4444, dport=1000 + i, flags="F")
            for i in range(30)
        ]
        assert len(_feed(PortScanDetector(20, 10), probes, "6.6.6.6")) == 1

    def test_udp_replies_are_not_counted(self):
        """e.g. a DNS resolver answering lookups from many ephemeral ports."""
        pkts = [
            Ether() / IP(src="8.8.8.8") / UDP(sport=53, dport=50000 + i)
            for i in range(30)
        ]
        assert _feed(PortScanDetector(20, 10), pkts, "8.8.8.8") == []


# ---------------------------------------------------------------------------
# Brute force
# ---------------------------------------------------------------------------

class TestBruteForce:
    def test_real_syn_flood_on_ssh_detected(self):
        syns = [Ether() / IP(src="9.9.9.9") / TCP(sport=2000 + i, dport=22, flags="S")
                for i in range(15)]
        alerts = _feed(BruteForceDetector(10, 10, [22]), syns, "9.9.9.9")
        assert len(alerts) == 1
        assert alerts[0].metadata["target_port"] == 22

    def test_syn_ack_is_not_an_attempt(self):
        pkts = [Ether() / IP(src="9.9.9.9") / TCP(sport=22, dport=22, flags="SA")
                for _ in range(15)]
        assert _feed(BruteForceDetector(10, 10, [22]), pkts, "9.9.9.9") == []

    def test_udp_with_df_flag_is_not_mistaken_for_a_syn(self):
        """On UDP, ``packet.flags`` is the IP flags; DF == 0x02 == SYN's bit."""
        pkts = [Ether() / IP(src="9.9.9.9", flags="DF") / UDP(dport=22)
                for _ in range(15)]
        assert _feed(BruteForceDetector(10, 10, [22]), pkts, "9.9.9.9") == []


# ---------------------------------------------------------------------------
# DoS
# ---------------------------------------------------------------------------

def _burst(detector, src_ip, second, count):
    alerts = []
    for k in range(count):
        a = detector.process(object(), src_ip, second + k / count)
        if a is not None:
            alerts.append(a)
    return alerts


class TestDoS:
    def test_alert_reports_the_real_sustained_rate(self):
        """Used to be a constant 1.0 because it read the brand-new second."""
        d = DoSDetector(threshold_pps=100, window_seconds=10, consecutive_intervals=3)
        alerts = []
        for sec in range(5):
            alerts += _burst(d, "6.6.6.6", 2000 + sec, 600)
        assert len(alerts) == 1
        assert alerts[0].metadata["packet_rate"] == 600.0

    def test_heavy_flood_is_critical(self):
        d = DoSDetector(threshold_pps=100, window_seconds=10, consecutive_intervals=3)
        alerts = []
        for sec in range(5):
            alerts += _burst(d, "6.6.6.6", 2000 + sec, 600)
        assert alerts[0].severity == Severity.CRITICAL

    def test_moderate_flood_is_high(self):
        d = DoSDetector(threshold_pps=100, window_seconds=10, consecutive_intervals=3)
        alerts = []
        for sec in range(5):
            alerts += _burst(d, "6.6.6.6", 2000 + sec, 200)
        assert alerts[0].severity == Severity.HIGH

    def test_bursts_separated_by_idle_seconds_are_not_consecutive(self):
        d = DoSDetector(threshold_pps=100, window_seconds=30, consecutive_intervals=3)
        alerts = []
        for base in (3000, 3003, 3006, 3009):   # 2 silent seconds between bursts
            alerts += _burst(d, "7.7.7.7", base, 200)
        alerts += _burst(d, "7.7.7.7", 3012, 1)
        assert alerts == []

    def test_back_to_back_seconds_still_alert_after_an_earlier_gap(self):
        d = DoSDetector(threshold_pps=100, window_seconds=30, consecutive_intervals=3)
        alerts = []
        alerts += _burst(d, "7.7.7.7", 3000, 200)     # lone burst
        for sec in range(4000, 4005):                  # then a real sustained one
            alerts += _burst(d, "7.7.7.7", sec, 200)
        assert len(alerts) == 1


# ---------------------------------------------------------------------------
# IP blocker input validation
# ---------------------------------------------------------------------------

class TestIPBlockerValidation:
    @pytest.mark.parametrize(
        "bad",
        ["0.0.0.0/0", "10.0.0.0/8", "any", "localsubnet", "-j", "127.0.0.1",
         "0.0.0.0", "224.0.0.1", "not-an-ip", ""],
    )
    def test_dangerous_values_never_reach_the_firewall(self, bad):
        blocker = IPBlocker()
        with patch("ids.ip_blocker.subprocess.run") as run:
            assert blocker.block(bad).success is False
            assert blocker.unblock(bad).success is False
            run.assert_not_called()

    @pytest.mark.parametrize("good", ["1.2.3.4", "192.168.1.20", "2001:db8::1"])
    def test_valid_addresses_are_passed_through(self, good):
        blocker = IPBlocker()
        with patch("ids.ip_blocker.subprocess.run") as run:
            run.return_value = MagicMock(returncode=0, stderr="")
            assert blocker.block(good).success is True
            run.assert_called_once()
